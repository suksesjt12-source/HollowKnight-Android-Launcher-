# Builder APK diagnostik Vulkan untuk Mali-G57

Proyek ini menyiapkan APK diagnostik dari probe resmi yang sudah ada di repositori `shirai91/nx2android`. APK bukan emulator, bukan backend Mali, dan tidak mengubah driver ponsel. Tugasnya mengukur kemampuan Vulkan ponsel untuk menentukan hambatan port native.

## Apa yang diukur

- Nama GPU, vendor/device ID, versi Vulkan dan driver.
- Fitur Vulkan penting, termasuk `textureCompressionBC`, ETC2, ASTC, geometry shader, descriptor indexing, timeline semaphore, dan dynamic rendering.
- Dukungan format tekstur BC1–BC7, ASTC, ETC2 serta format render/depth.
- Ekstensi Vulkan yang tersedia.
- Uji jalur memori GPU/CPU (zero-copy) yang dipakai penelitian backend nx2android.
- Probe CPU/kernel tambahan dari proyek upstream.

## Membuat APK melalui GitHub Actions

1. Unduh ZIP proyek ini lalu ekstrak.
2. Buat repositori GitHub baru, misalnya `mali-vulkan-probe`.
3. Unggah `build_probe.sh`, `README_ID.md`, dan `SOURCE_COMMIT.txt` ke repositori.
4. Buat file workflow secara terpisah melalui **Add file → Create new file**. Beri nama/path persis `.github/workflows/build-probe.yml`, lalu salin isi file `build-probe.yml` dari ZIP ini dan simpan. (Titik di awal `.github` memang harus ada.)
5. Buka tab **Actions**, pilih **Build Mali Vulkan diagnostic APK**, lalu tekan **Run workflow**. Jika tab Actions belum muncul, buka tab **Actions** lalu aktifkan workflow bila GitHub memintanya.
6. Setelah selesai, buka hasil workflow dan unduh artifact `nx2a-mali-vulkan-probe`. Di dalamnya ada `nx2a-probe.apk`.
7. Pasang APK itu di ponsel Infinix, buka **NX2A Probe**, lalu tunggu sampai tertulis `DONE`.
8. Geser layar untuk membaca hasil. Salin atau foto seluruh bagian `== device`, `== features`, `== extensions`, `== formats`, `== zero-copy`, dan hasil akhir. Kirimkan hasilnya untuk dianalisis.

Workflow memakai Android NDK r27c dan mengambil sumber probe resmi pada commit yang dipatok agar build dapat diulang. Tidak perlu memasukkan NSP/XCI, `prod.keys`, atau data pribadi ke repositori.

## Catatan penting

- APK ini hanya mengumpulkan hasil pengukuran. Ia **belum** mengaktifkan dukungan Mali pada nx2android.
- Probe berjalan di dalam proses aplikasi Android biasa, bukan sebagai root.
- Hasil probe membantu menentukan kompatibilitas Vulkan, tetapi tidak membuktikan bahwa game tertentu sudah bisa dimainkan.
- Jika workflow gagal, kirimkan teks error dari log build; jangan mengubah kode backend berdasarkan tebakan.

## Sumber dan atribusi

Sumber probe yang dibangun berasal dari repositori resmi `https://github.com/shirai91/nx2android`, khususnya `probes/vkprobe.c`, `probes/vkzc.c`, `probes/cpuprobe.c`, `probes/app/probeapp.c`, dan `probes/app/mkapk.py`. Semua lisensi dan atribusi sumber upstream tetap berlaku. File pada proyek ini hanya menyediakan skrip build dan workflow.
